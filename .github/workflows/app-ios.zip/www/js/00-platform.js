/* Reading Journal - Platform detection (native iOS, native Android, web) and haptics. Loaded first; shared scope. */
var RJ=(function(){var C=window.Capacitor,nat=!!(C&&C.isNativePlatform&&C.isNativePlatform()),p=(C&&C.getPlatform&&C.getPlatform())||'web',ua=navigator.userAgent||'',iosDev=/iPad|iPhone|iPod/.test(ua)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
return{native:nat,nativeIos:nat&&p==='ios',android:p==='android',ios:p==='ios'||(!nat&&iosDev),standalone:!!(navigator.standalone||(window.matchMedia&&matchMedia('(display-mode: standalone)').matches))}})();
function hap(k){try{var H=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.Haptics;if(!H)return;if(k==='ok')H.notification({type:'SUCCESS'});else if(k==='warn')H.notification({type:'WARNING'});else H.impact({style:k==='heavy'?'HEAVY':'LIGHT'})}catch(e){}}
/* Offline support for the installed web app (not used inside the native wrapper). */
try{if('serviceWorker' in navigator&&!RJ.native&&/^https?:$/.test(location.protocol))addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){})})}catch(e){}

/* Reading Journal - Core: polyfills, saved data, helpers, page rendering. Loaded in order with the other js files; they share one scope. */

if(!Array.prototype.flatMap)Array.prototype.flatMap=function(f){return[].concat.apply([],this.map(f))};
if(!Promise.allSettled)Promise.allSettled=function(a){return Promise.all(Array.prototype.map.call(a,function(p){return Promise.resolve(p).then(function(v){return{status:'fulfilled',value:v}},function(e){return{status:'rejected',reason:e}})}))};
if(!Promise.prototype.finally)Promise.prototype.finally=function(f){var P=this.constructor||Promise;return this.then(function(v){return P.resolve(f()).then(function(){return v})},function(e){return P.resolve(f()).then(function(){throw e})})};
const K='rgj1',$=s=>document.querySelector(s);let S;
try{S=JSON.parse(localStorage.getItem(K))}catch(e){}
S=S||{books:[],sessions:[],notes:[],goals:[],profile:{},yg:12,timer:null};
const save=()=>{try{localStorage.setItem(K,JSON.stringify(S))}catch(e){toast('Could not save: storage is full or blocked')}};
const uid=()=>Math.random().toString(36).slice(2,10),esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ld=d=>{d=d||new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const sum=(a,k)=>a.reduce((t,x)=>t+(+x[k]||0),0),num=v=>Math.max(0,parseInt(v)||0);
const ST={want:'Want to Read',reading:'Currently Reading',paused:'Paused',done:'Completed',dropped:'Abandoned'};
const NAV=[['dash','Home','🏠'],['lib','Library','📚'],['reading','Reading','📖'],['want','Want','🔖'],['done','Done','✅'],['notes','Notes','📝'],['docs','Docs','📄'],['goals','Goals','🎯'],['alarms','Alarms','⏰'],['recs','For You','🎁'],['profile','Profile','👤'],['stats','Stats','📊'],['trash','Trash','🗑️'],['settings','Settings','⚙️']];
let V='dash',Q={q:'',st:'',sort:'added'},NID=null;
function toast(m){const t=$('#toast');t.textContent=m;t.style.display='block';clearTimeout(t.h);t.h=setTimeout(()=>t.style.display='none',2500)}
function cfm(m,fn,no){const d=$('#dlg2');d.innerHTML=`<p>${esc(m)}</p><div class=row><button class=p id=cy>Confirm</button><button id=cn>Cancel</button></div>`;d.showModal();$('#cy').onclick=()=>{d.close();fn()};$('#cn').onclick=()=>{d.close();if(no)no()}}
const book=id=>S.books.find(b=>b.id==id),pct=b=>b.pages?Math.min(100,Math.round(b.cur/b.pages*100)):null;
const hue=s=>[...String(s)].reduce((h,c)=>(h*31+c.charCodeAt(0))%360,7);
function streak(){const d=new Set(S.sessions.map(s=>s.date));let n=0,x=new Date();if(!d.has(ld(x)))x.setDate(x.getDate()-1);while(d.has(ld(x))){n++;x.setDate(x.getDate()-1)}return n}
function days(n){const m={};S.sessions.forEach(s=>{const o=m[s.date]||(m[s.date]={p:0,m:0});o.p+=+s.pages||0;o.m+=+s.mins||0});const o=[];for(let i=n-1;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=ld(d),v=m[k]||{p:0,m:0};o.push({l:k.slice(5),p:v.p,m:v.m})}return o}
const bars=(a,k)=>{const mx=Math.max(1,...a.map(x=>x[k]));return'<div class=bars>'+a.map(x=>`<div title="${x.l}: ${x[k]}" style="height:${x[k]/mx*100}%"></div>`).join('')+'</div>'};
const pb=p=>`<div class=pb><i style="width:${p||0}%"></i></div>`;
function genres(){const m={};S.books.forEach(b=>{const g=b.genre||'Uncategorized';m[g]=(m[g]||0)+1});return Object.entries(m).sort((a,b)=>b[1]-a[1])}
const genreHtml=()=>{const g=genres(),mx=g.length?g[0][1]:1;return g.length?g.map(([n,c])=>`<div class=mu>${esc(n)} (${c})</div>${pb(c/mx*100)}`).join(''):'<p class=mu>No books yet.</p>'};
function tm(){const o=$('#menu').classList.toggle('open');$('#scrim').classList.toggle('open',o);$('#mb').setAttribute('aria-expanded',o)}
function go(v){V=v;NID=null;lastBack=0;render();scrollTo(0,0)}
function render(){renderNav();$('#main').innerHTML=(VW[V]||VW.lib)();if(VI[V])VI[V]();$('#fab').style.display=['dash','lib','want','reading','done'].includes(V)?'flex':'none'}
